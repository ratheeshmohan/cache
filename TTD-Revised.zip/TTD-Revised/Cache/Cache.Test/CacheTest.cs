﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using TTD.Cache;

namespace Cache.Test
{

    [TestClass]
    public class CacheTest
    {
        [TestMethod]
        public void CreateCacheTest()
        {
            var cache = new Cache<uint, uint, long>(16, 4, new LruEvictionStrategy());
            Assert.IsNotNull(cache);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CreateCache_InalidInput()
        {
             var cache = new Cache<uint, uint, long>(15, 4, new LruEvictionStrategy());
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CreateCache_InalidInput_()
        {
             var cache = new Cache<uint, uint, long>(16, 5, new LruEvictionStrategy());
        }


        [TestMethod]
        public void Get_Key_Should_Return_Correct_Value_1()
        {
            var cache = new Cache<object, object, long>((uint) Math.Pow(2, 24), 8, new LruEvictionStrategy());
             
            for (var i = 0; i < Math.Pow(2, 15); ++i)
            {
                cache.Set(i, i);
                var res = cache.Get(i);

                Assert.IsTrue(res.IsSome);
                Assert.AreEqual(res.Value, i);
            }
        }
        
        [TestMethod]
        public void Get_Key_Should_Return_Correct_Value()
        { 

            var cache = new Cache<uint, uint, long>(1, 1, new LruEvictionStrategy());
            cache.Set(1, 1);
            cache.Set(1, 1);
            cache.Set(2, 2);

            var res1 = cache.Get(1);
            Assert.IsTrue(res1.IsNone);

            var res2 = cache.Get(2);
            Assert.IsTrue(res2.IsSome);
        }
        
        [TestMethod]
        public void Set_Same_Key_Sequentially_Should_Miss_Only_Once()
        {

            var counter = 0;
            var hasEvicted = false;
            var lruStrategy = new Mock<IEvictionStrategy<long>>();
            //Return value same as key
            lruStrategy.Setup(f => f.DefaultMeta).Returns(0);
            lruStrategy.Setup(f => f.Renew(It.IsAny<uint>(),It.IsAny<long>())).Returns(++counter);
            lruStrategy.Setup(f => f.Evict(It.IsAny<long>(), It.IsAny<long>())).Returns((long l, long r) =>
            {
                hasEvicted = true;
                return l<r? Direction.Left : Direction.Right;
            });

          
            var cache = new Cache<uint, uint, long>(16, 8, lruStrategy.Object);
            cache.Get(1);
            cache.Get(1);
            cache.Get(1);
            Assert.AreEqual(counter, 1);
            Assert.IsFalse(hasEvicted);
        }

       
        [TestMethod]
        public void Lru_Key_Must_Be_Evicted()
        {
            var cache = new Cache<uint, uint, long>(2, 2, new LruEvictionStrategy());
            cache.Set(1,1);
            cache.Set(2, 2);
            cache.Set(3, 3);

            Assert.IsTrue(cache.Get(1).IsNone);
            Assert.IsTrue(cache.Get(2).IsSome);
            Assert.IsTrue(cache.Get(3).IsSome);
        }
       
        [TestMethod]
        public void Miss_Hit_Should_Be_Same_On_Two_Instances_Having_Same_Paramaters()
        {
            var counter1 = 0;
            var missCount1 = 0U;
            var lruStrategy1 = new Mock<IEvictionStrategy<long>>();
            //Return value same as key
            lruStrategy1.Setup(f => f.DefaultMeta).Returns(0);
            lruStrategy1.Setup(f => f.Renew(It.IsAny<uint>(), It.IsAny<long>())).Returns(++counter1);
            lruStrategy1.Setup(f => f.Evict(It.IsAny<long>(), It.IsAny<long>())).Returns((long l, long r) =>
            {
                missCount1++;
                return l < r ? Direction.Left : Direction.Right;
            });

            var counter2 = 0;
            var missCount2 = 0U;
            var lruStrategy2 = new Mock<IEvictionStrategy<long>>();
            //Return value same as key
            lruStrategy2.Setup(f => f.DefaultMeta).Returns(0);
            lruStrategy2.Setup(f => f.Renew(It.IsAny<uint>(), It.IsAny<long>())).Returns(++counter2);
            lruStrategy2.Setup(f => f.Evict(It.IsAny<long>(), It.IsAny<long>())).Returns((long l, long r) =>
            {
                missCount2++;
                return l < r ? Direction.Left : Direction.Right;
            });

            var cache1 = new Cache<uint, uint, long>(32, 8, lruStrategy1.Object);
            var cache2 = new Cache<uint, uint, long>(32, 8, lruStrategy2.Object);
            for (var i = 0U; i < 100; ++i)
            {
                cache1.Set(i,i);
                cache2.Set(i,i);
            }
            for (var i = 0U; i < 100; ++i)
            {
                cache1.Get(i);
                cache2.Get(i);
            }
            Assert.AreEqual(missCount1, missCount2);
            Assert.AreEqual(counter1, counter2);
        }
       
       

       [TestMethod]
       public void Test_Lru()
       {
           var cache = new Cache<uint, int, long>(4, 4, new LruEvictionStrategy());
           cache.Set(1,1);
           cache.Set(2,2);
           cache.Set(3,3);
           cache.Set(4,4);
           cache.Set(5,5);
            
           Assert.IsTrue(cache.Get(1).IsNone);
           Assert.AreEqual(cache.Get(2).Value, 2);
           Assert.AreEqual(cache.Get(3).Value, 3);
           Assert.AreEqual(cache.Get(4).Value, 4);
           Assert.AreEqual(cache.Get(5).Value, 5);

        }

        [TestMethod]
       public void Test_Mru()
        {
            var cache = new Cache<uint, int, long>(4, 4, new MruEvictionStrategy());
            cache.Set(1, 1);
            cache.Set(2, 2);
            cache.Set(3, 3);
            cache.Set(4, 4);
            cache.Set(5, 5);

            Assert.IsTrue(cache.Get(4).IsNone);
            Assert.AreEqual(cache.Get(5).Value, 5);
            Assert.AreEqual(cache.Get(3).Value, 3);
            Assert.AreEqual(cache.Get(2).Value, 2);
            Assert.AreEqual(cache.Get(1).Value, 1);

            cache.Set(4, 4);
            Assert.IsTrue(cache.Get(1).IsNone);
            Assert.AreEqual(cache.Get(4).Value,4);


        }

    }
}
