﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TTD.Cache.Utilities;

namespace Cache.Test
{
    [TestClass]
    public class SliceTest
    {
        [TestMethod]
        public void SliceWithArraySize0()
        {
            var array = new int[0];
            var slice = new Slice<int>(array, 0, 0);
            Assert.AreEqual(slice.Length, 0U);
        }

        [TestMethod]
        public void SliceOnArrayHavingSizeGreaterThan0()
        {
            var array = new int[10];
            Enumerable.Range(0, 10).Select((x, i) => array[i] = x);

            var slice = new Slice<int>(array, 0, 10);
            for (var i = 0U; i < 10; i++)
            {
                Assert.AreEqual(array[i], slice[i]);
            }
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void AccessIndexOutsideLength()
        {
            var array = new int[10];
            var slice = new Slice<int>(array, 0, 10) { [10U] = 3 };
        }

        [TestMethod]
        public void SetValueInSlice()
        {
            var array = new int[10];
            var slice = new Slice<int>(array, 4, 5) { [4] = -5 };
            Assert.AreEqual(array[8], slice[4]);
        }

        [TestMethod]
        public void RandomTest()
        {
            var rnd = new Random();
            var length = rnd.Next() % 100 + 1;
            var array = new int[length];
            for (var i = 0; i < length; ++i)
            {
                array[i] = rnd.Next();
            }

            //Execute test for 50 times
            for (var i = 0; i < rnd.Next() % 50 + 1; ++i)
            {
                var start = rnd.Next() % length;
                var sliceLength = rnd.Next() % (length - start);
                var slice = new Slice<int>(array, (uint)start, (uint)sliceLength);

                //Assert the values obtained from original array and slice are equal
                for (uint x = 0; x < sliceLength; x++)
                {
                    Assert.AreEqual(slice[x], array[start + x]);
                }
            }
        }
    }
}
