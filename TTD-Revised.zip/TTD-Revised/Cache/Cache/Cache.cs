using System;
using Newtonsoft.Json;
using System.Security.Cryptography;
using System.Text;
using Cache.utilities;
using TTD.Cache.Utilities;

namespace TTD.Cache
{
    ///<summary>
    ///A Cache for storing arbitary type Keys and Values.
    ///</summary>
    ///<remarks>
    /// Keys are stored as byte array,each key is represented by  28 bytes structure{[0][1]..[27]#[28]..[55]#.....}
    /// Values are stored as array of TValue
    /// Metadatas are stored as array of TMeta.
    ///</remarks>
    public class Cache<TKey, TValue, TMeta> : ICache<TKey, TValue>
    {
        internal static class Sha256HashGenerator
        {
            public static byte[] GetHash(object data)
            {
                var jsonData = JsonConvert.SerializeObject(data);
                return SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(jsonData));
            }
        }

        private struct KeyMeta
        {
            public uint SetNumber;
            public byte[] HashTag;
        }

        private struct SetDetails
        {
            public uint SetNumber;
            public uint SetIndex;
            public uint KeysSetIndex;
            public uint? ItemIndex;
            public byte[] HashTag;
        }

        private const uint TagBytesCount = 28;
        private readonly uint _length;
        private readonly uint _ways;
        private readonly uint _setCountLn2;
        private readonly byte[] _keys;
        private readonly TValue[] _values;
        private readonly TMeta[] _metas;
        private readonly IEvictionStrategy<TMeta> _evictionStrategy;

        ///<summary>
        ///Ctr for creating an instance.
        ///</summary>
        /// <param name="lengthPowOf2">Length of the cache,which should be an exact power of 2</param>
        /// <param name="nWaysPowOf2">Length of the set,which should be an exact power of 2</param>
        /// <param name="evictionStrategy">Strategy to fetch the meta details of the element access</param>
        public Cache(uint lengthPowOf2, uint nWaysPowOf2,
           IEvictionStrategy<TMeta> evictionStrategy)
        {
            if (lengthPowOf2 < 1 || !IsPowerOfTwo(lengthPowOf2))
                throw new ArgumentException("Argument must be >0 and pow of 2");
            if (nWaysPowOf2 < 1 || !IsPowerOfTwo(nWaysPowOf2))
                throw new ArgumentException("Argument must be >0 and pow of 2");
            if (evictionStrategy == null)
                throw new ArgumentNullException(nameof(evictionStrategy));


            _length = lengthPowOf2;
            _ways = nWaysPowOf2;
            _evictionStrategy = evictionStrategy;
            _values = new TValue[_length];
            _metas = new TMeta[_length];
            _keys = new byte[_length * TagBytesCount];
            _setCountLn2 = (uint)Math.Log(_length / _ways, 2);

            SetDefaultMeta();
        }

        public void Set(TKey key, TValue value)
        {
            var slotDetails = GetSetDetails(key);
            if (slotDetails.ItemIndex.HasValue)
            {
                //Hit. Update the new value in cache
                _values[slotDetails.SetIndex + slotDetails.ItemIndex.Value] = value;
            }
            else
            {
                //Get Eviction Index
                var metaSlice = new Slice<TMeta>(_metas, slotDetails.SetIndex, _ways);
                var evIndex = GetEvictionIndex(metaSlice);

                // Store new value and reset Meta
                var location = slotDetails.SetIndex + evIndex;
                _metas[location] = _evictionStrategy.DefaultMeta;
                _values[location] = value;

                //Store hash key
                var keysSlice = new Slice<byte>(_keys, slotDetails.KeysSetIndex + evIndex * TagBytesCount, TagBytesCount);
                for (uint x = 0; x < TagBytesCount; x++)
                {
                    keysSlice[x] = slotDetails.HashTag[x];
                }

                //Update Meta for the Key
                UpdateMeta(slotDetails.SetNumber, slotDetails.SetIndex, evIndex);
            }
        }

        private uint GetEvictionIndex(Slice<TMeta> metaSlice)
        {
            if (metaSlice[0].Equals(_evictionStrategy.DefaultMeta))
                return 0;

            uint index = 0;
            for (uint i = 1; i < metaSlice.Length; ++i)
            {
                if (metaSlice[i].Equals(_evictionStrategy.DefaultMeta))
                {
                    index = i;
                    break;
                }

                if (_evictionStrategy.Evict(metaSlice[i], metaSlice[index]) == Direction.Left)
                    index = i;
            }
            return index;
        }

        public Option<TValue> Get(TKey key)
        {
            var slotDetails = GetSetDetails(key);

            //Miss
            if (!slotDetails.ItemIndex.HasValue)
            {
                return new None<TValue>();
            }

            //Hit
            UpdateMeta(slotDetails.SetNumber, slotDetails.SetIndex, slotDetails.ItemIndex.Value);
            //Return Cached value
            return new Some<TValue>(_values[slotDetails.SetIndex + slotDetails.ItemIndex.Value]);
        }

        private SetDetails GetSetDetails(TKey key)
        {
            //Get Signature of Key
            var meta = GetMeta(key);
            var setNumber = meta.SetNumber;
            var setIndex = setNumber * _ways;
            var keysSetIndex = setIndex * TagBytesCount;

            //Searching all the elements in the slot sequentially, irrespective of the actual filled slot length.
            //This wont be a problem as N will be small( possibly <8) in ideal case. 
            //Note: If need, we can extend the Keys array to include the filled length in first 4 bytes of Set.
            uint itemIndex = 0;
            var tagSlice = new Slice<byte>(meta.HashTag, 0, TagBytesCount);
            for (var start = keysSetIndex; itemIndex < _ways; ++itemIndex, start += TagBytesCount)
            {
                if (CompareSlices(tagSlice, new Slice<byte>(_keys, start, TagBytesCount)))
                    break;
            }

            return new SetDetails
            {
                SetNumber = setNumber,
                SetIndex = setIndex,
                KeysSetIndex = keysSetIndex,
                ItemIndex = itemIndex < _ways ? itemIndex : new uint?(),
                HashTag = meta.HashTag
            };
        }

        private void UpdateMeta(uint setNumber, uint setIndex, uint itemIndex)
        {
            var slot = setIndex + itemIndex;
            _metas[slot] = _evictionStrategy.Renew(setNumber,_metas[slot]);
        }

        private KeyMeta GetMeta(TKey key)
        {
            var hashBytes = Sha256HashGenerator.GetHash(key);
            var hashLast32Bit = BitConverter.ToUInt32(new[] { hashBytes[28], hashBytes[29], hashBytes[30], hashBytes[31] }, 0);
            //Get SetNumber
            var setIndex = _setCountLn2 == 0 ? 0 : hashLast32Bit % (0xFFFFFFFF >> (int)(32 - _setCountLn2));

            //Signature of Index 
            var tag = new byte[28];
            Array.Copy(hashBytes, 0, tag, 0, 27);
            return new KeyMeta { SetNumber = setIndex, HashTag = tag };
        }

        private void SetDefaultMeta()
        {
            var defaultMeta = _evictionStrategy.DefaultMeta;
            for (var i = 0; i < _length; ++i)
                _metas[i] = defaultMeta;
        }

        private static bool CompareSlices<T>(Slice<T> a, Slice<T> b)
        {
            if (a.Length != b.Length)
                return false;

            var result = true;
            for (uint i = 0; i < a.Length && result; ++i)
                result &= a[i].Equals(b[i]);

            return result;
        }

        private static bool IsPowerOfTwo(uint n)
        {
            return (n & (n - 1)) == 0;
        }
    }
}