using System;
using TTD.Cache.Utilities;

namespace TTD.Cache
{
    public class LruEvictionStrategy : IEvictionStrategy<long>
    {
        private long _counter;

        public long DefaultMeta => long.MaxValue;

        public long Renew(uint setNumber, long currentMeta)
        {
            return ++_counter;
        }

        public Direction Evict(long left, long right)
        {
            return left < right ? Direction.Left : Direction.Right;
        }
    }
}