using Cache.utilities;

namespace TTD.Cache{
    
    public interface ICache<in TKey, TValue>
    {
        Option<TValue> Get(TKey key);

        void Set(TKey key, TValue value);
    }
}