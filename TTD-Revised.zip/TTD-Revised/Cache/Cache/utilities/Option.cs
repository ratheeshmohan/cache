﻿namespace Cache.utilities
{
    // A basic implementation for monadic behaviour in C#.
    public abstract class Option<T>
    {
        public abstract T Value { get; }
        public abstract bool IsSome { get; }
        public abstract bool IsNone { get; }
    }

    public sealed class None<T> : Option<T>
    {
        public override T Value
        {
            get { throw new System.NotSupportedException("There is no value in None"); }
        }

        public override bool IsSome => false;
        public override bool IsNone => true;
    }

    public sealed class Some<T> : Option<T>
    {
        public Some(T value)
        { 
            Value = value;
        }

        public override T Value { get; }
        public override bool IsSome => true;
        public override bool IsNone => false;
    }
}
