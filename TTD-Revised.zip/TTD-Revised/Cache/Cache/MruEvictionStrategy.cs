using System;
using TTD.Cache.Utilities;

namespace TTD.Cache
{
    public class MruEvictionStrategy : IEvictionStrategy<long>
    {
        private long _counter;

        public long DefaultMeta => 0;

        public long Renew(uint setNumber, long currentMeta)
        {
            return ++_counter;
        }

        public Direction Evict(long left, long right)
        {
            return left < right ? Direction.Right : Direction.Left;
        }
    }
}