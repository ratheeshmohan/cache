namespace TTD.Cache
{
    public enum Direction
    {
        Left,
        Right
    }

    public interface IEvictionStrategy<TMeta>
    {
       /// <summary>
       /// Returns the default value to be used as Meta
       /// </summary>
        TMeta DefaultMeta { get; }
        
        /// <summary>
        /// Renew the meta of a key in a particular slot
        /// </summary>
        /// <param name="setNumber"></param>
        /// <param name="currentMeta"></param>
        /// <returns></returns>
        //SetNumber is provided just in case to have any custom strategy.
        TMeta Renew(uint setNumber, TMeta currentMeta);

        /// <summary>
        /// Evict either left of right key based on eviction policy.
        /// </summary>
        /// <param name="left"></param>
        /// <param name="right"></param>
        /// <returns></returns>
        Direction Evict(TMeta left, TMeta right);
    }
}