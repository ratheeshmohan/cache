﻿using System;
using TTD.Cache;

namespace MainApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var cache = new Cache<object, object, long>((uint)Math.Pow(2, 18), 8,
                new LruEvictionStrategy());

            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();
            var end = Math.Pow(2, 20);
            //  for (long i=0; i < end ; ++i)
            for (var i = end; i>0; --i)
            {
                cache.Set(i, i);
            }

            uint missCount = 0;
            // for (long i = 0; i < end; ++i)
            for (var i = end; i > 0; --i)
            {
                var res = cache.Get(i);
                if (res.IsNone)
                    missCount++;
            }
            sw.Stop();
            Console.WriteLine("Total fetch count = {0}", end);
            Console.WriteLine("Total miss count = {0}", missCount);
            Console.WriteLine("Total miss % = {0}", (missCount/end )* 100);

            Console.WriteLine("Total Time Elapsed in ms = {0}", sw.ElapsedMilliseconds);
            Console.WriteLine("Avg Time Elapsed in ms = {0}", sw.ElapsedMilliseconds/2*end);
        }
    }
}
